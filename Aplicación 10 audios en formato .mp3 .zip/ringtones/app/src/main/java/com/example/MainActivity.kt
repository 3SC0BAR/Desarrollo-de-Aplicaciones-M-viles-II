package com.example.ringtones

import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class RingtoneItem(val name: String, val audioResId: Int)

class MainActivity : AppCompatActivity() {

    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ringtonesList = listOf(
            RingtoneItem("Tono Buen Fin 1", R.raw.audio1),
            RingtoneItem("Tono Buen Fin 2", R.raw.audio2),
            RingtoneItem("Tono Oferta 3", R.raw.audio3),
            RingtoneItem("Tono Promoción 4", R.raw.audio4),
            RingtoneItem("Tono Especial 5", R.raw.audio5),
            RingtoneItem("Tono Notificación 6", R.raw.audio6),
            RingtoneItem("Tono Alarma 7", R.raw.audio7),
            RingtoneItem("Tono Mensaje 8", R.raw.audio8),
            RingtoneItem("Tono Éxito 9", R.raw.audio9),
            RingtoneItem("Tono Cierre 10", R.raw.audio10)
        )

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewRingtones)
        recyclerView.layoutManager = LinearLayoutManager(this)
        
        recyclerView.adapter = RingtoneAdapter(ringtonesList) { ringtone ->
            playAudio(ringtone.audioResId, ringtone.name)
        }
    }

    private fun playAudio(audioResId: Int, audioName: String) {
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer.create(this, audioResId)
            mediaPlayer?.start()
            Toast.makeText(this, "Reproduciendo: $audioName", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Añade el archivo MP3 correspondiente en res/raw/", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
